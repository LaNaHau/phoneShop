package ptithcm.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import ptithcm.entity.DonHangEntity;

public interface DonHangDAO{
	public void luuDonHang(DonHangEntity donHang);
	public void updateDonHang(DonHangEntity donHang);
	public DonHangEntity timDonHangTheoMa(int maDh);
	public List<DonHangEntity> timDonHangCuaUserTheoTrangThai(int maNd, int trangThai);
	public List<DonHangEntity> layDonHangTheoMaVoucher (String maVoucher);
	
	public List<DonHangEntity> layAllDonHang();	
	public List<DonHangEntity> layDonHangTheoTrangThai(int trangThai);
	public long tinhTongDoanhThuTheoThang(int thang);
	
	public List<DonHangEntity> timDonHangTheoTrangThaiVaThuocTinhKhac(
		    Integer trangThai, 
		    String hoTen, 
		    Date ngayTaoMin, 
		    Date ngayTaoMax);
	
	public List<String> layMaSanPhamTrongDonHangGanNhatCuaUser(int maNd);
}