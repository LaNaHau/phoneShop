package ptithcm.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import ptithcm.entity.NguoiDungEntity;

@Transactional
@Repository
public class nguoiDungDaoImpl implements nguoiDungDao {

	@Autowired
	SessionFactory factory;

	@Override
	public void addUser(NguoiDungEntity user) {
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		try {
			session.save(user);
			t.commit();

		} catch (Exception ex) {
			t.rollback();
			System.out.print("loi");

		} finally {
			session.close();
		}

	}

	@Override
	public void updateUser(NguoiDungEntity user) {
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		try {
			session.update(user);
			t.commit();

		} catch (Exception ex) {
			t.rollback();
			System.out.print("loi");

		} finally {
			session.close();
		}

	}

	@Override
	public NguoiDungEntity findUserById(Integer maNd) {
		Session session = factory.getCurrentSession();
		String hql = "FROM NguoiDungEntity nd WHERE nd.maNd = :maNd ";
		Query query = session.createQuery(hql).setParameter("maNd", maNd);
		NguoiDungEntity user = (NguoiDungEntity) query.uniqueResult();
		return user;

	}

	@Override
	public NguoiDungEntity findUserByNameAndEmail(String userName, String email) {
		Session session = factory.getCurrentSession();
		String hql = "FROM NguoiDungEntity nd WHERE nd.userName = :userName OR nd.email = :email";
		Query query = session.createQuery(hql);
		query.setParameter("userName", userName);
		query.setParameter("email", email);

		List<NguoiDungEntity> user = query.list();
		if(user.size()>0)
		return user.get(0);
		
		return null;
	}

	@Override
	public List<NguoiDungEntity> getAllUserByRole(Integer maQuyen) {
		Session session = factory.getCurrentSession();
		String hql = "FROM NguoiDungEntity nd WHERE nd.quyen = :maQuyen";
		Query query = session.createQuery(hql);
		query.setParameter("maQuyen", maQuyen);

		List<NguoiDungEntity> listUser = query.list();
		return listUser;
	}
	
	@Override
	public List<NguoiDungEntity> findUserByName(String hoTen) {
		Session session = factory.getCurrentSession();
		String hql = "FROM NguoiDungEntity nd WHERE nd.hoTen LIKE :hoTen AND nd.quyen = 0";
		Query query = session.createQuery(hql).setParameter("hoTen",  "%" + hoTen + "%");
		
		List<NguoiDungEntity> users = query.list();
		return users;

	}
	@Override
	public List<NguoiDungEntity> findUserByNames(String hoTen) {
	    Session session = factory.getCurrentSession();
	    System.out.print("Ten trong DAO"+hoTen);
	    // Nếu hoTen không rỗng và chứa dấu phẩy, tách nó thành danh sách
	    if (hoTen != null && !hoTen.trim().isEmpty()) {
	        // Tách các tên từ chuỗi hoTen, sử dụng dấu phẩy làm phân cách
	        String[] hoTenArray = hoTen.split("\\s*,\\s*"); // Tách chuỗi theo dấu phẩy và loại bỏ khoảng trắng

	        // Xây dựng câu truy vấn động với LIKE cho từng tên
	        StringBuilder hql = new StringBuilder("FROM NguoiDungEntity nd WHERE nd.quyen = 0");

	        // Thêm điều kiện LIKE cho mỗi họ tên
	        for (int i = 0; i < hoTenArray.length; i++) {
	            if (i == 0) {
	                hql.append(" AND nd.hoTen LIKE :hoTen" + i);
	            } else {
	                hql.append(" OR nd.hoTen LIKE :hoTen" + i);
	            }
	        }

	        // Tạo truy vấn và thiết lập các tham số
	        Query query = session.createQuery(hql.toString());

	        // Thiết lập tham số LIKE cho từng tên trong mảng
	        for (int i = 0; i < hoTenArray.length; i++) {
	            query.setParameter("hoTen" + i, "%" + hoTenArray[i].trim() + "%");
	        }

	        // Thực thi truy vấn và trả về kết quả
	        List<NguoiDungEntity> users = query.list();
	        return users;
	    }

	    // Nếu không có tên nào được nhập, trả về danh sách rỗng hoặc bạn có thể xử lý theo cách khác.
	    return new ArrayList<>();
	}

}